#include <stdio.h>
#include "callee.h"

void SayHello() {
    printf("Hello, world!\n");
}
